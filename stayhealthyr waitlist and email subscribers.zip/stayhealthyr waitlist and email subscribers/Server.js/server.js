const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mailchimp = require('@mailchimp/mailchimp_marketing');

const app = express();
app.use(bodyParser.json());
app.use(cors());

mailchimp.setConfig({
  apiKey: 'd3fa74a3abb567f8f4c48ea14b5f2951-us14',
  server: 'us14'
});

const listId = '8e8083c6fb';

app.post('/check-email', async (req, res) => {
  const { email } = req.body;

  try {
    const response = await mailchimp.lists.getListMember(listId, email);
    return res.status(200).json({ exists: true });
  } catch (error) {
    if (error.status === 404) {
      return res.status(200).json({ exists: false });
    }
    console.error('Error checking email:', error);
    return res.status(500).json({ error: 'An error occurred while checking the email.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
